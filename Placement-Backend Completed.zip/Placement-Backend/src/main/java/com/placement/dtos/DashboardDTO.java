package com.placement.dtos;

public class DashboardDTO {

	private int students;
	private int hods;
	private int company;
	private int selected;
	
	public int getStudents() {
		return students;
	}
	public void setStudents(int students) {
		this.students = students;
	}
	public int getHods() {
		return hods;
	}
	public void setHods(int hods) {
		this.hods = hods;
	}
	public int getCompany() {
		return company;
	}
	public void setCompany(int company) {
		this.company = company;
	}
	public int getSelected() {
		return selected;
	}
	public void setSelected(int selected) {
		this.selected = selected;
	}
	
	
}
